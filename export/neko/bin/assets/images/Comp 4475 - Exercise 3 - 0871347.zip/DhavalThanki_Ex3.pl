person(alice).
person(the_husband).
person(the_son).
person(the_daughter).
person(alices_brother).

children(the_son).
children(the_daughter).

male(the_husband).
male(the_son).
male(alices_brother).

female(alice).
female(the_daughter).

twin(alice, alices_brother).
twin(alices_brother, alice).

younger(the_daughter, alice).
younger(the_son, alice).
younger(the_son, the_husband).
younger(the_daughter, the_husband).

checkTwin(X) :- twin(X, _).

checkBar(M, F) :-  person(M), person(F),
  			 	   male(M),   female(F).

together(A, B) :- 
    A = alice, 
    B = the_husband.

together(A, B) :- 
    A = the_husband,
    B = alice. 

alone(P) :- 
    person(P), 
    children(P).

/* Rule Combination */
solution(Murderer, Victim, BarMan, BarWoman, Alone) :-
    person(Murderer), 
    person(Victim),

    	/* Clue 1 */ 
       	checkBar(BarMan, BarWoman),
			BarMan \= Murderer, BarMan \= Victim, 
    		BarWoman \= Murderer,	BarWoman \= Victim,
    
     	/* Clue 2 */
       		\+ together(Murderer, Victim), 
			Murderer \= Victim,
    
     	/* Clue 3 */
		alone(Alone),
			Alone \= BarMan, Alone \= BarWoman,
			Alone \= Murderer, Alone \= Victim,

    	/* Clue 4 */
        	\+ together(BarMan, BarWoman),
    
    	/* Clue 5 */
        checkTwin(Victim), 
 			\+ twin(Victim, Murderer),

    	/* Clue 6 */
        	\+ younger(Victim, Murderer).

solve_it :-
solution(Murderer, Victim, BarMan, BarWoman, Alone),
format('
~w killed ~w.
~w and ~w were together in the bar.
~w was alone.', [Murderer, Victim, BarMan, BarWoman, Alone]).

